#!/usr/bin/env python3
import os
import json
import hashlib
import hmac
import base64
import python_jwt as jwt
import jwcrypto.jwk as jwk, datetime
from jinja2 import Environment, FileSystemLoader, select_autoescape
from http.cookies import SimpleCookie
from urllib.parse import quote, unquote
import cgi
import cgitb

def check_password(password, salt, pass_hash):
    return hmac.compare_digest(pass_hash, hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000))

def parse_jwt(cookies, key):
    header, claims = None, None
    if "AUTH" in cookies:
        auth_cookie = unquote(cookies["AUTH"].value)
        header, claims = jwt.verify_jwt(auth_cookie, key, ['HS512'])
    return header, claims

if __name__ == "__main__":
    cgitb.enable(display=0, logdir="/tmp")
    status = 'Status: 200 OK'

    with open("/etc/users.json") as f: users = json.load(f)
    JWT_KEY = jwk.JWK.from_password(os.environ["JWT_KEY"])

    env = Environment(
        loader=FileSystemLoader("/var/www/html/jinja2-html"),
        autoescape=select_autoescape()
    )

    cookies = SimpleCookie(os.environ.get("HTTP_COOKIE", default=""))
    new_cookies = SimpleCookie()
    header, claims = parse_jwt(cookies, JWT_KEY)

    template_result = ""

    if os.environ["REQUEST_METHOD"] == "POST":
        form = cgi.FieldStorage()
        username = form.getfirst("username")
        password = form.getfirst("password")
        login_success = False

        # DEV LOGIN: user:nd4DuFLLmpvF

        pass_hash, salt = None, None
        if username in users and password:
            salt, pass_hash = [base64.b64decode(n) for n in users[username].split(":")]
            if check_password(password, salt, pass_hash):
                new_cookies["AUTH"] = quote(jwt.generate_jwt({"sub": username}, JWT_KEY, 'HS512', datetime.timedelta(hours=24)))
                status = "Status: 302 Found"
                print("Location: /")
                login_success = True

        if not login_success:
            status = "Status: 401 Unauthorized"
            template_result = env.get_template("index.html").render(error="Invalid username or password") 
    else:
        if claims is None or "sub" not in claims:
            template_result = env.get_template("index.html").render()
        elif claims["sub"] != "admin":
            template_result = env.get_template("logged-in.html").render(sub=claims["sub"])
        else:
            template_result = env.get_template("logged-in.html").render(sub=claims["sub"], message=os.environ["FLAG"])
    
    print(status)
    print('Content-Type: text/html;charset=utf-8')
    print(new_cookies)
    print()
    print(template_result)

